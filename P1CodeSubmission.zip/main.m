%% ASEN 3802 - Lab 3 - Main
% Task 1: Create NACA Airfoil Generator, Plot Results
% Task 2: Vortex Panel Method, N Panel Convergence
% Task 3: Symmetric Airfoil Cl vs alpha
% Task 4: Cambered Airfoil Cl vs alpha
% Author: Cooper, Nathan, Sayer, Xander
% Date: Mar 31, 2026

clc; clear all; close all;

%% Task 1, NACA 0021, NACA 2421
% Airfoils for Task 1
airfoil1 = 'NACA_0021';
airfoil2 = 'NACA_2421';

N = 50; % Number of Panels for top and bottom each
c = 1; % Chord length

% Plotting and Calculations for Airfoil 1
[m,p,t] = extractAirfoilData(airfoil1); % Calc m,p,t
[x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,N); % Calc geometry
PlotAirfoil(x_b,y_b,y_c,x,c,airfoil1); % Plot geometry

% Plotting and Calculations for Airfoil 2
[m,p,t] = extractAirfoilData(airfoil2);
[x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,N);
PlotAirfoil(x_b,y_b,y_c,x,c,airfoil2);


%% Task 2, Vortex Panel Method
% Find cl of NACA 0012 at Alpha = 12 deg, Find N panels to converge to < 1% error
p2plot = 1;
if p2plot == 1
% Input parameters for Vortex Panel
airfoil3 = 'NACA_0012';
c = 1;
NumPanels = linspace(10,500,491);
alpha = 12; % AoA, degrees
[m,p,t] = extractAirfoilData(airfoil3);

predicted_cl = zeros(1,length(NumPanels));
% Loop for N panel convergence
for i = 1:length(NumPanels)
    [x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,NumPanels(i));
    predicted_cl(i) = Vortex_Panel(x_b,y_b,alpha);
end

% Caluclate "exact" cl with large number of panels, store to save future run time
% [x_b,y_b,y_c,x] = NACA_Airfoils(m,p,t,c,3000);
% exact_cl = Vortex_Panel(x_b,y_b,alpha);
exact_cl = 1.438326093800802;

% Percent Difference Formula, check if % diff < 1% error
[val, idx] = find((abs(exact_cl-predicted_cl)./((exact_cl + predicted_cl)./2) .* 100) < 1,1,"first");

% Plot of predicted cl vs number of panels used for calculation
figure(); hold on;
plot(2*NumPanels,predicted_cl,'b');
yline(exact_cl,'k');
yline(1.01*exact_cl,'r--');
yline(0.99*exact_cl,'r--');
xline(2*NumPanels(idx),'g--',LineWidth=2);
xlabel("Total Number of Panels (N)");
ylabel("Predicted Sectional Lift Coefficient (c_l)");
title("Predicted Sectional Lift Coefficient vs Number of Panels");
legend("Predicted c_l","Exact c_l","1% Error Bounds","","Min Number of Panels for < 1% Error",Location="southeast");

% Print needed info to command window
fprintf("Sectional Lift Coefficient (cl) for NACA 0012 at 12 degrees: %.3f \n", exact_cl);
fprintf("Min Number of Panels Needed for < 1 Percent Error from Exact: %.1f \n",2*NumPanels(idx));

% Extracting Data For Table
% Use 10, 50, 100, 200, 500 (Multiply by 2 for Total Panels)
% Cl, Num Panels, Relative Error, Min Panels for Convergence (separate)
Panels = [10, 50, 100, 200, 500];
TotPanels = zeros(1,5);
Cls = zeros(1,5);
RelativeError = zeros(1,5);
Names = ["Tot Panels","Cl","Relative Error"];
for i = 1:5
    idx = find(NumPanels == Panels(i),1,"first");
    Cls(i) = predicted_cl(idx);
    TotPanels(i) = Panels(i);
    RelativeError(i) = (abs(exact_cl-Cls(i))/(exact_cl+Cls(i))/2) * 100; % Convert to %
end
p2table = table(2.*Panels',Cls',RelativeError','VariableNames',Names)
end
minpanels = 76; % Numpanels(idx), hard coded to save time

%% Part 3, Effect of Airfoil Thickness on Lift
load("NACA0006.mat");
load("NACA0012.mat");
% load("NACA0018.mat");
p3names = ["NACA0006","NACA0012","NACA0018"];
p3Airfoils.(p3names(1)) = NACA0006;
p3Airfoils.(p3names(2)) = NACA0012;
% p3Airfoils.(p3names(3)) = NACA0018;
% Temp Names for VP loop
airfoil4 = 'NACA_0006';
airfoil5 = 'NACA_0012';
airfoil6 = 'NACA_0018';
tempp3names = {airfoil4,airfoil5,airfoil6};
colors = {'r','b','k'};

% Thin Airfoil Theory, still need
clalpha0.tat = zeros(3,1);

% Generating TaT Data
alphavec = linspace(-10,20,100);
for i = 1:length(tempp3names)
    tempclvec = zeros(1,length(alphavec));
    [m,p,t] = extractAirfoilData(tempp3names{i});
    [x_b,y_b,y_c,x,slope] = NACA_Airfoils(m,p,t,c,minpanels);
    clalpha0.tat(i) = ZeroLiftAoA(slope,x,c);
    % Predicted Cl from TaT 2pi(alpha-alphaL=0)
    for ii = 1:length(alphavec)
        tempclvec(ii) = 2*pi*deg2rad(alphavec(ii)-clalpha0.tat(i));
    end
    TaT.(tempp3names{i}) = tempclvec;
end

figure(); hold on;
% Chart data
for i = 1:length(p3names)
    % Don't plot 0018 b/c data missing
    if i ~= 3
        plotClvsAlphaExp(p3Airfoils.(p3names(i)).data(1).y,p3Airfoils.(p3names(i)).data(1).x,p3Airfoils.(p3names(i)).name,colors{i});
        plot(alphavec,TaT.(tempp3names{i}),'--','DisplayName',p3Airfoils.(p3names(i)).name + " Thin Airfoil Theory",Color=colors{i});
    else
        plot(alphavec,TaT.(tempp3names{i}),'--','DisplayName',"NACA 0018 Thin Airfoil Theory",Color=colors{i});
    end
end
% Calculated data
xlabel("Angle of Attacks (°)");
ylabel("Sectional Coefficient of Lift");
title("Comparison of Airfoil Cl vs Angle of Attack");
legend(Location="northwest");

% Put in Table form
% Vortex Panel
clalpha0.vp = zeros(3,1);
% Experimental
clalpha0.exp = zeros(3,1);

for i = 1:length(p3names) % remove 1 later when 0018 uploaded
    targalpha = 0;
    % VP Method
    [m,p,t] = extractAirfoilData(tempp3names{i});
    [x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,minpanels);
    % Cl from 2 AoA
    alpha0 = Vortex_Panel(x_b,y_b,0);
    alpha5 = Vortex_Panel(x_b,y_b,5);
    slope = (alpha5-alpha0)/5;
    clalpha0.vp(i) = alpha0/slope; % AoA for Cl = 0
    % Experimental
    if i ~=3
        alpha_data = p3Airfoils.(p3names(i)).data(1).x;
        cl_data = p3Airfoils.(p3names(i)).data(1).y;
        clalpha0.exp(i) = interp1(cl_data, alpha_data, targalpha, 'linear');
    else
        clalpha0.exp(i) = "N/A";
    end
end

% Combine all data into tables
t1names = ["Airfoil","Vortex Panel","Thin Airfoil Theory","Experimental"];
alphaL0tab = table(p3names',clalpha0.vp,clalpha0.tat,clalpha0.exp,'VariableNames',t1names)

% Table form 
clslope.vp = zeros(3,1);
clslope.tat = zeros(3,1);
clslope.exp = zeros(3,1);

for i = 1:length(p3names)
    targalpha = 0;
    % TaT Const 2pi
    clslope.tat(i) = (2*pi)*pi/180; % pi/180 = 1°
    % VP
    [m,p,t] = extractAirfoilData(tempp3names{i});
    [x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,minpanels);
    cl0 = Vortex_Panel(x_b,y_b,targalpha);
    cl5 = Vortex_Panel(x_b,y_b,5);
    clslope.vp(i) = (cl5-cl0)/5;
    % Exp
    if i ~= 3
        alpha_data = p3Airfoils.(p3names(i)).data(1).x;
        cl_data = p3Airfoils.(p3names(i)).data(1).y;
        idx = (alpha_data >= -5 & alpha_data <= 5); % idk why && didn't work
        p = polyfit(alpha_data(idx), cl_data(idx), 1);
        clslope.exp(i) = p(1); % Extract slope (slope,intercept)
    else
        clslope.exp(i) = "N/A";
    end
end

estLiftSlope = table(p3names',clslope.vp,clslope.tat,clslope.exp,'VariableNames',t1names)

%% Part 4, Effect of Airfoil Thickness on Lift
load("NACA0012.mat");
load("NACA2412.mat");
load("NACA4412.mat");
p4names = ["NACA0012","NACA2412","NACA4412"];
p4Airfoils.(p4names(1)) = NACA0012;
p4Airfoils.(p4names(2)) = NACA2412;
p4Airfoils.(p4names(3)) = NACA4412;
% Temp Names for VP loop
airfoil7 = 'NACA_0012';
airfoil8 = 'NACA_2412';
airfoil9 = 'NACA_4412';
tempp4names = {airfoil7,airfoil8,airfoil9};

% Thin Airfoil Theory, still need
clalpha0.tat = zeros(3,1);

% Generating TaT Data
alphavec = linspace(-10,20,100);
for i = 1:length(tempp4names)
    tempclvec = zeros(1,length(alphavec));
    [m,p,t] = extractAirfoilData(tempp4names{i});
    [x_b,y_b,y_c,x,slope] = NACA_Airfoils(m,p,t,c,minpanels);
    clalpha0.tat(i) = ZeroLiftAoA(slope,x,c);
    % Predicted Cl from TaT 2pi(alpha-alphaL=0)
    for ii = 1:length(alphavec)
        tempclvec(ii) = 2*pi*deg2rad(alphavec(ii)-clalpha0.tat(i));
    end
    TaT.(tempp4names{i}) = tempclvec;
end

figure(); hold on;
% Chart data
for i = 1:length(p3names)
    plotClvsAlphaExp(p4Airfoils.(p4names(i)).data(1).y,p4Airfoils.(p4names(i)).data(1).x,p4Airfoils.(p4names(i)).name,colors{i});
    plot(alphavec,TaT.(tempp4names{i}),'--','DisplayName',p4Airfoils.(p4names(i)).name + " Thin Airfoil Theory",Color=colors{i});
end
% Calculated data
xlabel("Angle of Attacks (°)");
ylabel("Sectional Coefficient of Lift");
title("Comparison of Airfoil Cl vs Angle of Attack");
legend(Location="northwest");

% Put in Table form
% Vortex Panel
clalpha0.vp = zeros(3,1);
% Experimental
clalpha0.exp = zeros(3,1);

for i = 1:length(p4names) % remove 1 later when 0018 uploaded
    targalpha = 0;
    % VP Method
    [m,p,t] = extractAirfoilData(tempp4names{i});
    [x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,minpanels);
    % Cl from 2 AoA
    alpha0 = Vortex_Panel(x_b,y_b,0);
    alpha5 = Vortex_Panel(x_b,y_b,5);
    slope = (alpha5-alpha0)/5;
    clalpha0.vp(i) = -alpha0/slope; % AoA for Cl = 0
    % Experimental
    alpha_data = p4Airfoils.(p4names(i)).data(1).x;
    cl_data = p4Airfoils.(p4names(i)).data(1).y;
    clalpha0.exp(i) = interp1(cl_data, alpha_data, targalpha, 'linear');
end

% Combine all data into tables
t1names = ["Airfoil","Vortex Panel","Thin Airfoil Theory","Experimental"];
alphaL0tab = table(p4names',clalpha0.vp,clalpha0.tat,clalpha0.exp,'VariableNames',t1names)

% Table form 
clslope.vp = zeros(3,1);
clslope.tat = zeros(3,1);
clslope.exp = zeros(3,1);

for i = 1:length(p4names)
    targalpha = 0;
    % TaT Const 2pi
    clslope.tat(i) = (2*pi)*pi/180; % pi/180 = 1°
    % VP
    [m,p,t] = extractAirfoilData(tempp4names{i});
    [x_b,y_b,y_c,x,~] = NACA_Airfoils(m,p,t,c,minpanels);
    cl0 = Vortex_Panel(x_b,y_b,targalpha);
    cl5 = Vortex_Panel(x_b,y_b,5);
    clslope.vp(i) = (cl5-cl0)/5;
    % Exp
    alpha_data = p4Airfoils.(p4names(i)).data(1).x;
    cl_data = p4Airfoils.(p4names(i)).data(1).y;
    idx = (alpha_data >= -5 & alpha_data <= 5); % idk why && didn't work
    p = polyfit(alpha_data(idx), cl_data(idx), 1);
    clslope.exp(i) = p(1); % Extract slope (slope,intercept)
end

estLiftSlope = table(p4names',clslope.vp,clslope.tat,clslope.exp,'VariableNames',t1names)

%% Functions
% Functions for Part 1
function [x_b,y_b,y_c,x,slope] = NACA_Airfoils(m,p,t,c,N)
    %{
    Inputs:
        m - max camber
        p - location of max camber
        t - max thickness
        c - chord length
        N - Number of Panels
    Outputs:
        x_b - X coordinates of boundary
        y_b - Y coordinates of boundary
        y_c - Mean camber line y coords
         x  - X coordinates generated by ray method
      slope - slope of camber line?
    %}
    % Create x value array using ray method
    x = GeometricXValues(N,c);
    % Calculates the thickness distribution of airfoil
    y_t = (t*c/0.2)*((0.2969*sqrt(x/c) - 0.1260*(x/c)-0.3516*(x/c).^2 + 0.2843*(x/c).^3 - 0.1036*(x/c).^4));
    % Preallocate arrays
    xi = zeros(1,length(x));
    dyc = zeros(1,length(x));
    y_c = zeros(1,length(x));

    % Finds the mean camber line. Splits it between before the maximum camber
    % position and after. Will go to 0 if there is no camber.
    for i = 1:length(x)
        % If before max camber position
        if x(i) < p*c
            % y coordinate camber modification
            y_c(i) = m*x(i)/p^2 * (2*p-x(i)/c);
            %dyc/dx
            dyc(i) = (2*p-2*x(i)/c)*m/p^2;
            % Angle calculation
            xi(i)= atan(dyc(i));
        % If after max camber position
        elseif x(i) >= p*c
            y_c(i) = m*(c-x(i))/(1-p)^2 * (1+(x(i)/c)-(2*p));
            dyc(i) = m/(1-p)^2*(2*p-2*x(i)/c);
            xi(i) = atan(dyc(i));
        end
    end
    
    x_L = x + y_t.*sin(xi);
    x_U = x - y_t.*sin(xi);
    y_L = y_c - y_t.*cos(xi);
    y_U = y_c + y_t.*cos(xi);
    % Concatenate Upper and Lower in CW Trailing Edge, modify indices so
    % doesn't double up array values, flip for correct order
    x_b = [x_L, fliplr(x_U(1:end-1))]; % Flip x_U so that goes from left to right
    y_b = [y_L, fliplr(y_U(1:end-1))]; % Flip y_U so matches flipped x_U
    slope = dyc;
end

function [m,p,t] = extractAirfoilData(airfoilCode)
    %{
    Inputs: 
        airfoilCode - NACA_XXXX airfoil as a string, X's numbers
    Outputs:
        m - max camber
        p - location of max camber
        t - max thickness of airfoil
    %}
    code = airfoilCode(end-3:end); % Extract Numbers
    digits = code - '0'; % Convert to vector of digits
    m = digits(1)/100; % Calculate max camber
    p = digits(2)/10; % Calculate position of max camber 
    t = str2double(code(3:4))/100; % Calculate thickness
end

function [x_array] = GeometricXValues(Number_of_Panels,C)

%GeometrixXValues finds X values based off the gemoetric method highlighted
%in class,
%This function takes the desired number of panels and the chord length. It
%takes N panels as equivalent to N rays, from the point c/2 to a circle
%with radius of c/2. Taking the number of rays over 2pi radians gives the
%equal angle between them. We make an array of rays, spaced by the equal
%angle we've found. Then we just take the dot product of the ray and the
%x-axis to get an array of x values, between 0 and c.
%
% Author: Sayer Gage
% Collaborators: Xander Lotito
% Date: 03/31/26
% Modified change from 2pi to pi to get rid of doubling coord error
Number_of_Rays = Number_of_Panels; %The number of rays we have should be
%equivalent to the number of panels we want.
Angle = pi / Number_of_Rays; %The equal angle should just be the number of arrays 
%divided by the full arc of the circle
Angle_array = 0:Angle:pi; %this is an array describing all the rays, as described
%by their angle clockwise from the TE
x_array = (C/2)*cos(Angle_array) + C/2; %This takes the x-projection of each
%ray to get an array of N+1 x points on the x-axis, giving N panels.
end

function PlotAirfoil(x_b,y_b,y_c,x,c,name)
    %{
    Inputs:
        x_b - x coords TE on bottom to LE to on TE top
        y_b - y coords, same CW order from TE
        y_c - mean camber line
         x  - x coordinates for camber line plotting
        c - chord length for plot scaling
        name - airfoil name for title
    Outputs:
        Plot of Airfoil geometry
    %}
    figure(); hold on; grid on;
    plot(x_b,y_b,"Marker",".",DisplayName="Airfoil Boundary"); % Plotting Boundary of Airfoil
    % Adding Limits to x and y
    xlim([-0.05*c 1.05*c]);
    ylim([-c c]);
    % Labels and Title
    xlabel("X Position (0 to c)");
    ylabel("Y Position");
    title("Geometry of " + name + " Airfoil",Interpreter="none");
    % Only plot camber line if airfoil is cambered, Add legend for camber line vs boundary
    if any(y_c) % Runs if any values of y_c not equal to 0
        plot(x,y_c,'-b',DisplayName="Mean Camber Line"); % Plot camber line with x coordinates from ray generation
    end
    legend("show");
end

% Functions for Part 2
function [CL] = Vortex_Panel(XB,YB,ALPHA)
% Modified, removed VINF from inputs b/c not used in function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input:                           %
%                                  %
% XB  = Boundary Points x-location %
% YB  = Boundary Points y-location %
% VINF  = Free-stream Flow Speed   %
% ALPHA = AOA                      %
%                                  %
% Output:                          %
%                                  %
% CL = Sectional Lift Coefficient  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%
% Convert to Radians %
%%%%%%%%%%%%%%%%%%%%%%

ALPHA = ALPHA*pi/180;

%%%%%%%%%%%%%%%%%%%%%
% Compute the Chord %
%%%%%%%%%%%%%%%%%%%%%

CHORD = max(XB)-min(XB);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the Number of Panels %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M = max(size(XB,1),size(XB,2))-1;
MP1 = M+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Intra-Panel Relationships:                                  %
%                                                             %
% Determine the Control Points, Panel Sizes, and Panel Angles %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for I = 1:M
    IP1 = I+1;
    X(I) = 0.5*(XB(I)+XB(IP1));
    Y(I) = 0.5*(YB(I)+YB(IP1));
    S(I) = sqrt( (XB(IP1)-XB(I))^2 +( YB(IP1)-YB(I))^2 );
    THETA(I) = atan2( YB(IP1)-YB(I), XB(IP1)-XB(I) );
    SINE(I) = sin( THETA(I) );
    COSINE(I) = cos( THETA(I) );
    RHS(I) = sin( THETA(I)-ALPHA );
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inter-Panel Relationships:             %
%                                        %
% Determine the Integrals between Panels %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for I = 1:M
    for J = 1:M
        if I == J
            CN1(I,J) = -1.0;
            CN2(I,J) = 1.0;
            CT1(I,J) = 0.5*pi;
            CT2(I,J) = 0.5*pi;
        else
            A = -(X(I)-XB(J))*COSINE(J) - (Y(I)-YB(J))*SINE(J);
            B = (X(I)-XB(J))^2 + (Y(I)-YB(J))^2;
            C = sin( THETA(I)-THETA(J) );
            D = cos( THETA(I)-THETA(J) );
            E = (X(I)-XB(J))*SINE(J) - (Y(I)-YB(J))*COSINE(J);
            F = log( 1.0 + S(J)*(S(J)+2*A)/B );
            G = atan2( E*S(J), B+A*S(J) );
            P = (X(I)-XB(J)) * sin( THETA(I) - 2*THETA(J) ) ...
              + (Y(I)-YB(J)) * cos( THETA(I) - 2*THETA(J) );
            Q = (X(I)-XB(J)) * cos( THETA(I) - 2*THETA(J) ) ...
              - (Y(I)-YB(J)) * sin( THETA(I) - 2*THETA(J) );
            CN2(I,J) = D + 0.5*Q*F/S(J) - (A*C+D*E)*G/S(J);
            CN1(I,J) = 0.5*D*F + C*G - CN2(I,J);
            CT2(I,J) = C + 0.5*P*F/S(J) + (A*D-C*E)*G/S(J);
            CT1(I,J) = 0.5*C*F - D*G - CT2(I,J);
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inter-Panel Relationships:           %
%                                      %
% Determine the Influence Coefficients %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for I = 1:M
    AN(I,1) = CN1(I,1);
    AN(I,MP1) = CN2(I,M);
    AT(I,1) = CT1(I,1);
    AT(I,MP1) = CT2(I,M);
    for J = 2:M
        AN(I,J) = CN1(I,J) + CN2(I,J-1);
        AT(I,J) = CT1(I,J) + CT2(I,J-1);
    end
end
AN(MP1,1) = 1.0;
AN(MP1,MP1) = 1.0;
for J = 2:M
    AN(MP1,J) = 0.0;
end
RHS(MP1) = 0.0;

%%%%%%%%%%%%%%%%%%%%%%%%
% Solve for the gammas %
%%%%%%%%%%%%%%%%%%%%%%%%

GAMA = AN\RHS';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve for Tangential Veloity and Coefficient of Pressure %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for I = 1:M
    V(I) = cos( THETA(I)-ALPHA );
    for J = 1:MP1
        V(I) = V(I) + AT(I,J)*GAMA(J);
    end
    CP(I) = 1.0 - V(I)^2;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve for Sectional Coefficient of Lift %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CIRCULATION = sum(S.*V);
CL = 2*CIRCULATION/CHORD;
end

% Functions for Part 3
function plotClvsAlphaExp(cl,alpha,name,color)
    plot(alpha,cl,"DisplayName",name + " Experimental Data",Color=color);
end

function [ZeroLiftAoA] = ZeroLiftAoA(Slope,x,c)
%This function numerically integrates the thin airfoil theory equation to
%find the zero lift angle of attack
x = fliplr(x); % Gets rid of negative by flipping
theta_0 = (acos(1-(x.*(2/c))));

%t = cos(theta_0);
integrand = Slope .* (cos(theta_0) - 1);

Integral = trapz(theta_0,integrand);

% ZeroLiftAoA = -(180/pi)*((-1/pi) .* Integral);
ZeroLiftAoA = rad2deg((1/pi).*Integral); % got rid of 180/pi and negative

%There is a sign error somewhere in here
%I put a negative sign above in the last line, but there's no justification
%for it other than it fixes the sign error.
end